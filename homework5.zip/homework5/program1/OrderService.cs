﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program1
{
    class OrderService
    {
        private static List<OrderDetails> list = new List<OrderDetails>();
        //add order into list
        public static void AddOrder(OrderDetails order)
        {
            if ((Product.products.Find(a => a.Goods == order.Product)) != null)
            {
                foreach (Product a in Product.products)
                {
                    if (a.Goods == order.Product)
                    {
                        order.Price = a.Price;
                        list.Add(order);
                    }
                }
            }
            else
                throw new ArgumentOutOfRangeException("product doesn't exist");
        }
        //seek order by name
        public static OrderDetails SeekByName(string name)
        {
            /*
            foreach (OrderDetails a in list)
            {
                if (a.Client == name)
                    Console.WriteLine("======================================================");
                Console.WriteLine("查找结果： \t" + "客户姓名：" + a.Client + " \t" + "客户订单号：" + a.Num + " \t" + "商品：" + a.Product);
            }
            */
            var m = from n in list
                    where n.Client == name
                    select n;
            Console.WriteLine(m);
            return list.Find(c => c.Client == name);
        }
        //seek order by num
        public static OrderDetails SeekByNum(int num)
        {
            //foreach (OrderDetails a in list)
            //{
            //    if (a.Num == num)
            //        Console.WriteLine("===============================================");
            //    Console.WriteLine("查找结果： \t" + "客户姓名：" + a.Client + " \t" + "客户订单号：" + a.Num + " \t" + "商品：" + a.Product);
            //}
            var m = from n in list
                    where n.Num == num
                    select n;
            Console.WriteLine(m);
            return list.Find(c => c.Num == num);
        }
        //seek order by Product's name
        public static OrderDetails SeekByProduct(string Product)
        {
            //foreach (OrderDetails a in list)
            //{
            //    if (a.Product == Product)
            //        Console.WriteLine("================================================");
            //    Console.WriteLine("查找结果： \t" + "客户姓名：" + a.Client + " \t" + "客户订单号：" + a.Num + " \t" + "商品：" + a.Product);
            //}
            var m = from n in list
                    where n.Product == Product
                    select n;
            Console.WriteLine(m);
            return list.Find(c => c.Product == Product);
        }
        //delete order by num
        public static void DeleteAsNum(int num)
        {
            try
            {
                foreach (OrderDetails a in list)
                {
                    if (a.Num == num)
                    {
                        list.Remove(a);
                        Console.WriteLine($"订单号为：{num}的订单删除成功");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("订单号错误");
            }
        }
        //delete order by name
        public static void DeleteAsName(string name)
        {
            try
            {
                foreach (OrderDetails a in list)
                {
                    if (a.Client == name)
                    {
                        list.Remove(a);
                        Console.WriteLine($"用户名为：{name}的订单删除成功");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("用户姓名错误");
            }
        }
        //delete order by Product's name
        public static void DeleteAsPro(string Product)
        {
            try
            {
                foreach (OrderDetails a in list)
                {
                    if (a.Product == Product)
                    {
                        list.Remove(a);
                        Console.WriteLine($"商品为：{Product}的订单删除成功");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("商品不存在");
            }
        }
        //change order
        public static void Change(OrderDetails order1, OrderDetails order2)
        {

            OrderDetails c = list.Find(p => p == order1);
            Console.WriteLine("更改前： \t" + "客户姓名：" + c.Client + "\t" + "客户订单号：" + c.Num + "\t" + "商品：" + c.Product);
            c.Num = order2.Num;
            c.Client = order2.Client;
            c.Product = order2.Product;
            c.Price =order2.Price;
            Console.WriteLine("更改后： \t" + "客户姓名：" + c.Client + "\t" + "客户订单号：" + c.Num + "\t" + "商品：" + c.Product);

        }
        //print all orders
        public static void PrintAll()
        {
            int i = 1;
            foreach (OrderDetails a in list)
            {
                Console.WriteLine("================================================");
                Console.WriteLine(i+"\t"+a);
                i++;
            }
        }



    }
}
